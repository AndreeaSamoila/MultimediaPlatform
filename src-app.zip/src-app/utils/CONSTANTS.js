export const URL = 'http://localhost:3002';
export const URL_DOTNET = 'https://localhost:5001/api/';
//'https://localhost:5001/api/'
//192.168.0.3