﻿namespace ChatTest.App.Models
{
    public class ConversationGetModel : ConversationModel
    {
        public bool Read { get;set; }
    }
}
