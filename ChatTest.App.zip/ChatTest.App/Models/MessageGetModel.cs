﻿namespace ChatTest.App.Models
{
    public class MessageGetModel : MessageModel
    {
        public bool IsMine { get; set; }
    }
}
