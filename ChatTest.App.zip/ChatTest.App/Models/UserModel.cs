﻿namespace ChatTest.App.Models
{
    public class UserModel : UserGetModel
    {
        public string ConnectionId { get; set; }

        public string Token { get; set; }
    }
}
